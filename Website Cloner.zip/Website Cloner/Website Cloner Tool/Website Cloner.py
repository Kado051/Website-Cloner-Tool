# site_cloner.py
"""
site_cloner.py — Windows CMD Site Cloner Engine.
Requires: pip install httpx beautifulsoup4 selenium rich
"""

import os
import sys
import ctypes
import asyncio
import hashlib
import json
import mimetypes
import platform
import re
import time
import shutil
import tempfile
import traceback
from dataclasses import dataclass, field
from pathlib import Path
from urllib.parse import urlparse, urljoin, unquote, urldefrag

import httpx
from bs4 import BeautifulSoup
from rich.console import Console

SELENIUM_AVAILABLE = True
try:
    from selenium import webdriver
    from selenium.webdriver.chrome.options import Options as ChromeOptions
    from selenium.webdriver.edge.options import Options as EdgeOptions
    from selenium.webdriver.support.ui import WebDriverWait
except ImportError:
    SELENIUM_AVAILABLE = False

console = Console()

DEFAULT_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/124.0.0.0 Safari/537.36"
)

SKIP_SCHEMES = {"data", "javascript", "mailto", "tel", "blob", "about"}
HTML_EXTS = {".html", ".htm", ".xhtml", ""}
CSS_EXTS = {".css"}
JS_EXTS = {".js", ".mjs"}
IMG_EXTS = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".svg", ".ico", ".avif", ".bmp"}
FONT_EXTS = {".woff", ".woff2", ".ttf", ".otf", ".eot"}
MEDIA_EXTS = {".mp4", ".webm", ".ogg", ".mp3", ".wav", ".m4a", ".m3u8"}

# GİZLİ MOD — true ise pencere açılmaz
HEADLESS = True

BANNER = r"""
[bold green]
 █     █░▓█████  ▄▄▄▄     ██████  ██▓▄▄▄█████▓▓█████     ▄████▄   ██▓     ▒█████   ███▄    █ ▓█████  ██▀███  
▓█░ █ ░█░▓█   ▀ ▓█████▄ ▒██    ▒ ▓██▒▓  ██▒ ▓▒▓█   ▀    ▒██▀ ▀█  ▓██▒    ▒██▒  ██▒ ██ ▀█   █ ▓█   ▀ ▓██ ▒ ██▒
▒█░ █ ░█ ▒███   ▒██▒ ▄██░ ▓██▄   ▒██▒▒ ▓██░ ▒░▒███      ▒▓█    ▄ ▒██░    ▒██░  ██▒▓██  ▀█ ██▒▒███   ▓██ ░▄█ ▒
░█░ █ ░█ ▒▓█  ▄ ▒██░█▀    ▒   ██▒░██░░ ▓██▓ ░ ▒▓█  ▄    ▒▓▓▄ ▄██▒▒██░    ▒██   ██░▓██▒  ▐▌██▒▒▓█  ▄ ▒██▀▀█▄  
░░██▒██▓ ░▒████▒░▓█  ▀█▓▒██████▒▒░██░  ▒██▒ ░ ░▒████▒   ▒ ▓███▀ ░░██████▒░ ████▓▒░▒██░   ▓██░░▒████▒░██▓ ▒██▒
░ ▓░▒ ▒  ░░ ▒░ ░░▒▓███▀▒▒ ▒▓▒ ▒ ░░▓    ▒ ░░   ░░ ▒░ ░   ░ ░▒ ▒  ░░ ▒░▓  ░░ ▒░▒░▒░ ░ ▒░   ▒ ▒ ░░ ▒░ ░░ ▒▓ ░▒▓░
  ▒ ░ ░   ░ ░  ░▒░▒   ░ ░ ░▒  ░ ░ ▒ ░    ░     ░ ░  ░     ░  ▒   ░ ░ ▒  ░  ░ ▒ ▒░ ░ ░░   ░ ▒░ ░ ░  ░  ░▒ ░ ▒░
  ░   ░     ░    ░    ░ ░  ░  ░   ▒ ░  ░         ░      ░          ░ ░   ░ ░ ░ ▒     ░   ░ ░    ░     ░░   ░ 
    ░       ░  ░ ░            ░   ░              ░  ░   ░ ░          ░  ░    ░ ░           ░    ░  ░   ░     
                      ░                                 ░                                                                                                         
[/bold green]
"""

# ---------- Admin Check ----------

def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except Exception:
        return False

def run_as_admin():
    if os.name == 'nt' and not is_admin():
        script = os.path.abspath(sys.argv[0])
        params = ' '.join([f'"{arg}"' for arg in sys.argv[1:]])
        cmd_cmd = f'/k title Site Cloner & {sys.executable} "{script}" {params}'
        ctypes.windll.shell32.ShellExecuteW(
            None, "runas", "cmd.exe", cmd_cmd, None, 1
        )
        sys.exit()

# ---------- Helpers ----------

def is_skippable(url: str) -> bool:
    return urlparse(url).scheme.lower() in SKIP_SCHEMES

def strip_fragment(url: str) -> str:
    return urldefrag(url)[0]

def get_base_domain(netloc: str) -> str:
    parts = netloc.split('.')
    if len(parts) >= 2:
        return '.'.join(parts[-2:])
    return netloc

def safe_relpath(url: str, origin: str) -> str:
    p = urlparse(url)
    path = unquote(p.path or "/")
    ext = os.path.splitext(path)[1].lower()

    folder = ""
    if ext in IMG_EXTS or ext in FONT_EXTS or ext in MEDIA_EXTS:
        folder = "images/"
    elif ext in CSS_EXTS:
        folder = "css/"
    elif ext in JS_EXTS:
        folder = "js/"

    if path.endswith("/"):
        path += "index.html"
    rel = path.lstrip("/") or "index.html"

    parts = []
    for seg in rel.split("/"):
        if seg in ("", ".", ".."):
            continue
        seg = re.sub(r'[<>:"|?*\x00-\x1f,;]', "_", seg)
        if len(seg) > 50:
            name, ext2 = os.path.splitext(seg)
            h = hashlib.md5(name.encode()).hexdigest()[:8]
            seg = f"{name[:30]}_{h}{ext2}"
        parts.append(seg or "_")

    return folder + "/".join(parts)

def guess_ext_from_ct(content_type: str) -> str:
    if not content_type:
        return ""
    ct = content_type.split(";")[0].strip().lower()
    return mimetypes.guess_extension(ct) or ""

def normalize_url(base: str, href: str) -> str | None:
    if not href:
        return None
    href = href.strip()
    if not href or href.startswith("#"):
        return None
    if is_skippable(href):
        return None
    return strip_fragment(urljoin(base, href))

def rewrite_relpath(from_relpath: str, to_relpath: str) -> str:
    from_dir = os.path.dirname(from_relpath) or "."
    return os.path.relpath(to_relpath, from_dir).replace(os.sep, "/")

def default_downloads_dir() -> Path:
    home = Path.home()
    candidates: list[Path] = []
    if platform.system() == "Windows":
        up = os.environ.get("USERPROFILE")
        if up:
            candidates.append(Path(up) / "Downloads")
    elif platform.system() == "Darwin":
        candidates.append(home / "Downloads")
    else:
        xdg = os.environ.get("XDG_DOWNLOAD_DIR")
        if xdg:
            candidates.append(Path(xdg))
        candidates.append(home / "Downloads")
    for c in candidates:
        if c.is_dir():
            return c
    return Path.cwd()

def host_slug(url: str) -> str:
    url = url.strip().lower()
    if not url.startswith("http://") and not url.startswith("https://"):
        url = "https://" + url
    netloc = urlparse(url).netloc or "site"
    netloc = netloc.split(":")[0]
    netloc = netloc.split("@")[-1]
    netloc = re.sub(r'[^A-Za-z0-9.-]', "_", netloc)
    if netloc.startswith("www."):
        netloc = netloc[4:]
    return netloc or "site"

def is_likely_page(url: str) -> bool:
    parsed = urlparse(url)
    path = parsed.path.lower()
    ext = os.path.splitext(path)[1]
    if ext in HTML_EXTS or not ext:
        if not any(skip in path for skip in ['/api/', '/logout', '/signout', 'auth.', 'login?', 'register?']):
            return True
    return False

# ---------- Cloner Engine ----------

@dataclass
class Cloner:
    start_url: str
    output: Path
    max_pages: int = 1   # Sadece ana sayfa

    _client: httpx.AsyncClient | None = None
    _sem: asyncio.Semaphore | None = None
    _lock: asyncio.Lock = field(default_factory=asyncio.Lock)
    _seen_urls: set[str] = field(default_factory=set)
    _seen_paths: set[str] = field(default_factory=set)
    _url_to_path: dict[str, str] = field(default_factory=dict)
    _queue: asyncio.Queue = field(default_factory=asyncio.Queue)
    _pages_fetched: int = 0
    _root_origin: str = ""
    _rewrite_queue: list[tuple] = field(default_factory=list)
    _base_domain: str = ""
    _crawl_tasks: set = field(default_factory=set)
    _temp_profile: str = ""

    async def run(self) -> None:
        self._root_origin = self.start_url
        self._base_domain = get_base_domain(urlparse(self.start_url).netloc)
        self._temp_profile = tempfile.mkdtemp(prefix="site_cloner_profile_")

        self._client = httpx.AsyncClient(
            headers={"User-Agent": DEFAULT_UA, "Accept": "*/*"},
            follow_redirects=True,
            timeout=10.0,   # Düşürüldü
            verify=False,
        )
        self._sem = asyncio.Semaphore(8)
        self.output.mkdir(parents=True, exist_ok=True)

        if SELENIUM_AVAILABLE:
            try:
                await asyncio.wait_for(self._run_selenium(), timeout=180.0)
            except (asyncio.TimeoutError, Exception) as e:
                console.print(f"[bold red][fatal] Selenium failed: {type(e).__name__}: {e}[/bold red]")
                console.print(f"[dim]{traceback.format_exc()}[/dim]")
                console.print("[bold yellow][*] Falling back to basic HTTP mode...[/bold yellow]")
                await self._run_http()
        else:
            console.print("[bold yellow][warn] Selenium not installed. Using basic HTTP mode.[/bold yellow]")
            await self._run_http()

        await self._client.aclose()

        for rel, base_url, body, kind in self._rewrite_queue:
            if kind == "css":
                new_body = self._rewrite_css(base_url, rel, body)
                self._write(rel, new_body.encode("utf-8"))

        for rel, base_url, body, kind in self._rewrite_queue:
            if kind == "html":
                new_body = self._rewrite_html(base_url, rel, body)
                self._write(rel, new_body.encode("utf-8"))

        console.print(f"[bold green]{self._pages_fetched} pages, {len(self._seen_paths)} assets downloaded.[/bold green]")

    def _build_chrome_options(self) -> ChromeOptions:
        opts = ChromeOptions()
        if HEADLESS:
            opts.add_argument("--headless=new")
        opts.add_argument("--disable-gpu")
        opts.add_argument("--no-sandbox")
        opts.add_argument("--disable-dev-shm-usage")
        opts.add_argument("--window-size=1920,1080")
        opts.add_argument("--no-first-run")
        opts.add_argument("--no-default-browser-check")
        opts.add_argument("--remote-debugging-port=0")
        opts.add_argument("--log-level=3")
        opts.add_argument(f"--user-data-dir={self._temp_profile}")
        opts.add_argument(f"user-agent={DEFAULT_UA}")
        if platform.system() == "Windows":
            opts.add_argument("--disable-blink-features=AutomationControlled")
            opts.add_experimental_option("excludeSwitches", ["enable-automation"])
            opts.add_experimental_option("useAutomationExtension", False)
        opts.set_capability("goog:loggingPrefs", {"performance": "ALL"})
        return opts

    def _build_edge_options(self) -> EdgeOptions:
        opts = EdgeOptions()
        if HEADLESS:
            opts.add_argument("--headless=new")
        opts.add_argument("--disable-gpu")
        opts.add_argument("--no-sandbox")
        opts.add_argument("--disable-dev-shm-usage")
        opts.add_argument("--window-size=1920,1080")
        opts.add_argument("--no-first-run")
        opts.add_argument("--no-default-browser-check")
        opts.add_argument("--remote-debugging-port=0")
        opts.add_argument("--log-level=3")
        opts.add_argument(f"--user-data-dir={self._temp_profile}")
        opts.add_argument(f"user-agent={DEFAULT_UA}")
        if platform.system() == "Windows":
            opts.add_argument("--disable-blink-features=AutomationControlled")
            opts.add_experimental_option("excludeSwitches", ["enable-automation"])
            opts.add_experimental_option("useAutomationExtension", False)
        opts.set_capability("ms:loggingPrefs", {"performance": "ALL"})
        return opts

    def _get_driver(self):
        chrome_err = None
        try:
            driver = webdriver.Chrome(options=self._build_chrome_options())
            driver.execute_cdp_cmd("Page.addScriptToEvaluateOnNewDocument", {
                "source": "Object.defineProperty(navigator, 'webdriver', {get: () => undefined})"
            })
            return driver
        except Exception as e:
            chrome_err = e

        try:
            driver = webdriver.Edge(options=self._build_edge_options())
            driver.execute_cdp_cmd("Page.addScriptToEvaluateOnNewDocument", {
                "source": "Object.defineProperty(navigator, 'webdriver', {get: () => undefined})"
            })
            return driver
        except Exception as edge_err:
            raise RuntimeError(
                f"Could not start Chrome ({chrome_err}) or Edge ({edge_err})"
            )

    async def _run_selenium(self) -> None:
        console.print(f"[cyan][browser] Loading page: {self.start_url} ...[/cyan]")

        def _browser_task():
            driver = self._get_driver()
            try:
                driver.get(self.start_url)
                try:
                    WebDriverWait(driver, 60).until(
                        lambda d: d.execute_script("return document.readyState") == "complete"
                    )
                except Exception:
                    pass

                time.sleep(5)

                try:
                    driver.execute_script("""
                    (function() {
                        const cookieKeywords = ['cookie', 'consent', 'gdpr', 'çerez'];
                        const elements = document.querySelectorAll('div, section, aside, [role="dialog"]');
                        for (let i = 0; i < elements.length; i++) {
                            let el = elements[i];
                            let id = (el.id || '').toLowerCase();
                            let className = (typeof el.className === 'string' ? el.className : '').toLowerCase();
                            let style = window.getComputedStyle(el);
                            let has = cookieKeywords.some(k => id.includes(k) || className.includes(k));
                            if (has && (style.position === 'fixed' || style.position === 'sticky')) {
                                el.remove();
                            }
                        }
                        document.body.style.overflow = 'auto';
                        document.documentElement.style.overflow = 'auto';
                    })();
                    """)
                except Exception:
                    pass

                time.sleep(2)

                html = driver.page_source
                try:
                    logs = driver.get_log("performance")
                except Exception:
                    logs = []
                return html, logs
            finally:
                try:
                    driver.quit()
                except Exception:
                    pass

        html, logs = await asyncio.to_thread(_browser_task)

        shutil.rmtree(self._temp_profile, ignore_errors=True)

        console.print("[cyan][browser] Extracting network traffic assets...[/cyan]")

        asset_urls = set()
        for entry in logs:
            try:
                log = json.loads(entry["message"])
                if log["message"]["method"] == "Network.requestWillBeSent":
                    req_url = log["message"]["params"]["request"]["url"]
                    if req_url.startswith("http") and not is_skippable(req_url):
                        asset_urls.add(req_url)
            except Exception:
                pass

        console.print(f"[cyan][browser] Found {len(asset_urls)} assets. Downloading...[/cyan]")

        start_url = self.start_url
        rel = "index.html"
        self._url_to_path[start_url] = rel
        self._seen_paths.add(rel)

        for u in asset_urls:
            if u == start_url or strip_fragment(u) == strip_fragment(start_url):
                continue
            await self._enqueue_asset(u)

        workers = [asyncio.create_task(self._worker()) for _ in range(8)]

        try:
            await asyncio.wait_for(self._queue.join(), timeout=120.0)
        except asyncio.TimeoutError:
            console.print("[yellow][warn] Download queue timed out. Forcing exit...[/yellow]")

        for _ in workers:
            await self._queue.put(None)
        await asyncio.gather(*workers, return_exceptions=True)

        self._pages_fetched += 1
        async with self._lock:
            self._rewrite_queue.append((rel, start_url, html, "html"))

        # _extract_links_for_crawl BURADA ÇAĞRILMIYOR (crawler kapalı)

    def _extract_links_for_crawl(self, base_url: str, html: str) -> None:
        # Crawler tamamen devre dışı. Sadece istenen sayfa iner.
        pass

    async def _run_http(self) -> None:
        start = strip_fragment(self.start_url)
        await self._enqueue_asset(start)
        workers = [asyncio.create_task(self._worker()) for _ in range(8)]
        try:
            await asyncio.wait_for(self._queue.join(), timeout=120.0)
        except asyncio.TimeoutError:
            pass
        for _ in workers:
            await self._queue.put(None)
        await asyncio.gather(*workers, return_exceptions=True)

    async def _enqueue_asset(self, url: str) -> None:
        url = strip_fragment(url)
        if not url:
            return
        async with self._lock:
            if url in self._seen_urls:
                return
            # Sadece ana sayfa veya asset ise kuyruğa al
            if is_likely_page(url) and self._pages_fetched >= self.max_pages:
                return
            self._seen_urls.add(url)
            self._queue.put_nowait(url)

    async def _worker(self) -> None:
        while True:
            url = await self._queue.get()
            if url is None:
                self._queue.task_done()
                return
            try:
                await self._handle_asset(url)
            except Exception:
                pass
            finally:
                self._queue.task_done()

    async def _handle_asset(self, url: str) -> None:
        async with self._sem:
            try:
                resp = await self._client.get(url)
            except httpx.HTTPError:
                return

        if resp.status_code >= 400:
            return

        rel = safe_relpath(url, self._root_origin)
        ctype = resp.headers.get("content-type", "").lower()
        body = resp.content

        if "text/html" in ctype:
            async with self._lock:
                if self._pages_fetched >= self.max_pages:
                    return
                self._pages_fetched += 1
                if not rel.endswith(".html"):
                    rel += ".html"
                self._url_to_path[url] = rel
                self._seen_paths.add(rel)

            html = self._decode(resp)
            async with self._lock:
                self._rewrite_queue.append((rel, url, html, "html"))

            # _extract_links_for_crawl(url, html) BURADA DA KAPALI
            return

        if "text/css" in ctype or url.lower().split("?")[0].endswith(".css"):
            async with self._lock:
                self._url_to_path[url] = rel
                self._seen_paths.add(rel)
            await self._process_css(url, rel, self._decode(resp))
            return

        if "." not in os.path.basename(rel):
            ext = guess_ext_from_ct(ctype)
            if ext:
                rel += ext
        async with self._lock:
            self._url_to_path[url] = rel
            self._seen_paths.add(rel)
        self._write(rel, body)

    def _decode(self, resp: httpx.Response) -> str:
        try:
            return resp.text
        except Exception:
            return resp.content.decode("utf-8", errors="replace")

    def _write(self, rel: str, data: bytes) -> None:
        path = self.output / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)

    async def _process_css(self, base_url: str, rel: str, css: str) -> None:
        pending = []
        for u in self._extract_css_refs(css):
            if u.startswith("data:"):
                continue
            absu = normalize_url(base_url, u)
            if absu:
                pending.append(asyncio.ensure_future(self._enqueue_asset(absu)))
        if pending:
            await asyncio.gather(*pending, return_exceptions=True)
        async with self._lock:
            self._rewrite_queue.append((rel, base_url, css, "css"))

    def _extract_css_refs(self, css: str) -> list[str]:
        out = []
        for m in re.finditer(r'url\(\s*(["\']?)(.*?)\1\s*\)', css, flags=re.I | re.S):
            u = m.group(2).strip()
            if u and not is_skippable(u) and not u.startswith("#"):
                out.append(u)
        for m in re.finditer(r'@import\s+(?:url\(\s*)?(["\'])(.*?)\1', css, flags=re.I):
            out.append(m.group(2).strip())
        return out

    def _map(self, base_url: str, href: str) -> str | None:
        absu = normalize_url(base_url, href)
        return self._url_to_path.get(absu) if absu else None

    def _rewrite_html(self, base_url: str, rel: str, html: str) -> str:
        soup = BeautifulSoup(html, "html.parser")
        for link in soup.find_all("link", rel="stylesheet"):
            href = link.get("href")
            if href:
                local = self._map(base_url, href)
                if local:
                    link["href"] = rewrite_relpath(rel, local)

        def rw(el, attr: str, is_srcset: bool = False) -> None:
            v = el.get(attr)
            if not v:
                return
            if is_srcset:
                parts = []
                for part in v.split(","):
                    part = part.strip()
                    if not part:
                        continue
                    bits = part.split(None, 1)
                    u = bits[0]
                    rest = (" " + bits[1]) if len(bits) > 1 else ""
                    local = self._map(base_url, u)
                    parts.append((rewrite_relpath(rel, local) if local else u) + rest)
                el[attr] = ", ".join(parts)
                return
            local = self._map(base_url, v)
            if local:
                el[attr] = rewrite_relpath(rel, local)

        for tag, attr in [
            ("script", "src"), ("img", "src"), ("img", "data-src"),
            ("source", "src"), ("video", "src"), ("video", "poster"),
            ("audio", "src"), ("track", "src"), ("iframe", "src"),
            ("embed", "src"), ("object", "data"), ("a", "href"),
        ]:
            for el in soup.find_all(tag):
                rw(el, attr)

        for el in soup.find_all(["img", "source"]):
            rw(el, "srcset", is_srcset=True)

        for el in soup.find_all(id=re.compile(r"cookie|consent|gdpr", re.IGNORECASE)):
            el.decompose()
        for el in soup.find_all(class_=re.compile(r"cookie|consent|gdpr", re.IGNORECASE)):
            el.decompose()

        for a in soup.find_all("a", href=True):
            href = a["href"].strip()
            if href.startswith(("mailto:", "tel:", "javascript:", "#")):
                continue
            absu = normalize_url(base_url, href)
            if not absu:
                continue
            if absu in self._url_to_path:
                local = self._url_to_path[absu]
                a["href"] = rewrite_relpath(rel, local)

        return str(soup)

    def _rewrite_css(self, base_url: str, rel: str, css: str) -> str:
        def repl_url(m: re.Match) -> str:
            q = m.group(1) or ""
            u = m.group(2).strip()
            local = self._map(base_url, u)
            if local:
                return f'url({q}{rewrite_relpath(rel, local)}{q})'
            return m.group(0)

        css = re.sub(r'url\(\s*(["\']?)(.*?)\1\s*\)', repl_url, css, flags=re.I | re.S)

        def repl_import(m: re.Match) -> str:
            q = m.group(1)
            u = m.group(2).strip()
            local = self._map(base_url, u)
            if local:
                return f'@import {q}{rewrite_relpath(rel, local)}{q}'
            return m.group(0)

        return re.sub(r'@import\s+(["\'])(.*?)\1', repl_import, css, flags=re.I)

# ---------- Entry Point ----------

def main():
    run_as_admin()

    while True:
        os.system("cls")

        console.print(BANNER.strip() + "\n")
        console.print("[green]================================================================================[/green]")
        console.print("[green]Website Cloner - by AlphA[/green]")
        console.print("[green]================================================================================\n[/green]")
        console.print("[green]Enter Website to clone.\n[/green]")

        sys.stdout.write("\033[32mURL: \033[0m")
        sys.stdout.flush()
        url = input()

        if not url.strip():
            continue

        if not url.startswith("http"):
            url = "https://" + url

        out = (default_downloads_dir() / host_slug(url)).resolve()

        cloner = Cloner(start_url=url, output=out, max_pages=1)
        asyncio.run(cloner.run())

        console.print("\n[bold green]Press Enter to go back...[/bold green]", end="")
        input()

if __name__ == "__main__":
    main()