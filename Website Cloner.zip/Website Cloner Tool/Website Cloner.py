import os
import re
import sys
import ctypes
import requests
import concurrent.futures
import time
from urllib.parse import urljoin, urlparse
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.chrome.options import Options

def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

if not is_admin():
    script_path = os.path.abspath(sys.argv[0])
    ctypes.windll.shell32.ShellExecuteW(
        None, "runas", "cmd.exe", 
        f'/c chcp 65001 >nul && python "{script_path}"', None, 1
    )
    sys.exit()

ASCII_LOGO = r"""
█     █░▓█████  ▄▄▄▄     ██████  ██▓▄▄▄█████▓▓█████     ▄████▄   ██▓     ▒█████   ███▄    █ ▓█████  ██▀███  
▓█░ █ ░█░▓█   ▀ ▓█████▄ ▒██    ▒ ▓██▒▓  ██▒ ▓▒▓█   ▀    ▒██▀ ▀█  ▓██▒    ▒██▒  ██▒ ██ ▀█   █ ▓█   ▀ ▓██ ▒ ██▒
▒█░ █ ░█ ▒███   ▒██▒ ▄██░ ▓██▄   ▒██▒▒ ▓██░ ▒░▒███      ▒▓█    ▄ ▒██░    ▒██░  ██▒▓██  ▀█ ██▒▒███   ▓██ ░▄█ ▒
░█░ █ ░█ ▒▓█  ▄ ▒██░█▀    ▒   ██▒░██░░ ▓██▓ ░ ▒▓█  ▄    ▒▓▓▄ ▄██▒▒██░    ▒██   ██░▓██▒  ▐▌██▒▒▓█  ▄ ▒██▀▀█▄  
░░██▒██▓ ░▒████▒░▓█  ▀█▓▒██████▒▒░██░  ▒██▒ ░ ░▒████▒   ▒ ▓███▀ ░░██████▒░ ████▓▒░▒██░   ▓██░░▒████▒░██▓ ▒██▒
░ ▓░▒ ▒  ░░ ▒░ ░░▒▓███▀▒▒ ▒▓▒ ▒ ░░▓    ▒ ░░   ░░ ▒░ ░   ░ ░▒ ▒  ░░ ▒░▓  ░░ ▒░▒░▒░ ░ ▒░   ▒ ▒ ░░ ▒░ ░░ ▒▓ ░▒▓░
  ▒ ░ ░   ░ ░  ░▒░▒   ░ ░ ░▒  ░ ░ ▒ ░    ░     ░ ░  ░     ░  ▒   ░ ░ ▒  ░  ░ ▒ ▒░ ░ ░░   ░ ▒░ ░ ░  ░  ░▒ ░ ▒░
  ░   ░     ░    ░    ░ ░  ░  ░   ▒ ░  ░         ░      ░          ░ ░   ░ ░ ░ ▒     ░   ░ ░    ░     ░░   ░ 
    ░       ░  ░ ░            ░   ░              ░  ░   ░ ░          ░  ░    ░ ░           ░    ░  ░   ░     
                      ░                                 ░                                                    
"""

class WebsiteCloner:
    def __init__(self):
        self.download_dir = os.path.join(os.path.expanduser("~"), "Downloads")
        self.visited = set()
        self.queue = set()
        self.max_workers = 40 
        self.valid_exts = r'\.(png|jpg|jpeg|gif|webp|svg|css|js|woff2?|ttf|ico|json|mp4|webm|wasm)(\?|$)'
        self.image_counter = 1
        self.proxy = "" 

    def log(self, msg):
        print(msg)

    def get_local_path(self, url, site_dir, default_ext=".html", is_image=False):
        parsed = urlparse(url)
        path = parsed.path
        if not path or path.endswith("/"):
            path += "index" + default_ext
        if not os.path.splitext(path)[1] and default_ext:
            path += default_ext
        
        filename = os.path.basename(path)
        if not filename:
            filename = "file" + default_ext

        filename = re.sub(r'[\\/*?:"<>|]', "_", filename)

        if is_image:
            img_dir = os.path.join(site_dir, "Images")
            os.makedirs(img_dir, exist_ok=True)
            
            local_path = os.path.join(img_dir, filename)
            base_name, ext = os.path.splitext(filename)
            while os.path.exists(local_path):
                local_path = os.path.join(img_dir, f"{self.image_counter}_{base_name}{ext}")
                self.image_counter += 1
            return local_path

        return os.path.join(site_dir, filename)

    def extract_assets(self, text, base_url):
        try:
            urls = re.findall(r'(https?://[^\s"\'<>\\]+)', text)
            for u in urls:
                u = u.rstrip("\\'\",;")
                if re.search(self.valid_exts, u, re.IGNORECASE):
                    self.queue.add(u)
                    
            hidden_imgs = re.findall(r'[\'"]([^\'"]+\.(?:png|jpg|jpeg|gif|webp|svg|ico))[\'"]', text, re.IGNORECASE)
            for img in hidden_imgs:
                if not img.startswith("data:"):
                    full_url = urljoin(base_url, img)
                    self.queue.add(full_url)
        except Exception:
            pass

    def worker_download(self, url, site_dir, session):
        try:
            headers = {"Referer": urlparse(url).scheme + "://" + urlparse(url).netloc + "/"}
            resp = session.get(url, timeout=20, headers=headers)
            resp.raise_for_status()
            
            content_type = resp.headers.get("Content-Type", "")
            is_image = any(img_type in content_type for img_type in ["image/png", "image/jpeg", "image/svg", "image/webp", "image/gif"])

            local_path = self.get_local_path(url, site_dir, is_image=is_image)
            os.makedirs(os.path.dirname(local_path), exist_ok=True)

            if is_image:
                with open(local_path, "wb") as f:
                    f.write(resp.content)
                self.log(f"  [Image] Saved: {os.path.basename(local_path)}")
                return

            if "text/html" in content_type:
                self.extract_assets(resp.text, url)
                soup = BeautifulSoup(resp.text, "html.parser")
                if not soup.find("meta", attrs={"charset": True}):
                    meta = soup.new_tag("meta")
                    meta.attrs["charset"] = "utf-8"
                    if soup.head: soup.head.insert(0, meta)
                    else: soup.insert(0, meta)
                content_to_write = str(soup).encode("utf-8")
            else:
                content_to_write = resp.content
                if url.endswith(".css") or url.endswith(".js"):
                    self.extract_assets(resp.text, url)

            with open(local_path, "wb") as f:
                f.write(content_to_write)
            self.log(f"  [File] Saved: {os.path.basename(local_path)}")

        except Exception:
            pass

    def clone_website(self, url):
        try:
            domain = urlparse(url).netloc
            if not domain:
                domain = "cloned_site"
            site_dir = os.path.join(self.download_dir, domain.replace(":", "_"))
            os.makedirs(site_dir, exist_ok=True)

            self.log(f"[*] Starting clone of: {url}")
            self.log(f"[*] Saving to: {site_dir}")

            session = requests.Session()
            session.headers.update({
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
                "Accept-Language": "tr-TR,tr;q=0.9,en-US;q=0.8,en;q=0.7",
                "Connection": "keep-alive"
            })

            if self.proxy:
                session.proxies.update({"http": self.proxy, "https": self.proxy})
                self.log(f"[*] Using manual proxy: {self.proxy}")

            self.log(f"\n[*] Launching hidden Chrome to render JavaScript...")
            
            chrome_options = Options()
            chrome_options.add_argument("--headless=new") 
            chrome_options.add_argument("--disable-gpu")
            chrome_options.add_argument("--no-sandbox")
            chrome_options.add_argument("--log-level=3") 
            chrome_options.add_experimental_option('excludeSwitches', ['enable-logging'])
            chrome_options.add_argument("user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")

            if self.proxy:
                chrome_options.add_argument(f'--proxy-server={self.proxy}')

            try:
                driver = webdriver.Chrome(options=chrome_options)
                driver.set_page_load_timeout(30) 
                
                self.log(f"[*] Loading page... Please wait for JavaScript to render.")
                driver.get(url)
                time.sleep(10)
                
                rendered_html = driver.page_source
                driver.quit()
                self.log("[+] Page rendered successfully. Extracting assets...")
            except Exception as e:
                self.log(f"[!] Selenium failed: {e}")
                self.log("[*] Falling back to standard requests...")
                try:
                    resp = session.get(url, timeout=20)
                    rendered_html = resp.text
                except Exception as req_e:
                    self.log(f"[!] Requests also failed: {req_e}")
                    return

            soup = BeautifulSoup(rendered_html, "html.parser")
            
            if not soup.find("meta", attrs={"charset": True}):
                meta = soup.new_tag("meta")
                meta.attrs["charset"] = "utf-8"
                if soup.head: soup.head.insert(0, meta)
                else: soup.insert(0, meta)

            local_path = os.path.join(site_dir, "index.html")
            with open(local_path, "w", encoding="utf-8", errors="ignore") as f:
                f.write(str(soup))

            self.extract_assets(rendered_html, url)

            self.log(f"[*] Found {len(self.queue)} items to download. Starting threads...")
            
            with concurrent.futures.ThreadPoolExecutor(max_workers=self.max_workers) as executor:
                while True:
                    if not self.queue:
                        break
                    
                    batch = [self.queue.pop() for _ in range(min(len(self.queue), self.max_workers))]
                    futures = []
                    
                    for current_url in batch:
                        if current_url in self.visited:
                            continue
                        
                        self.visited.add(current_url)
                        self.log(f"\n[*] Progress: {len(self.visited)} saved, {len(self.queue)} in queue.")
                        futures.append(executor.submit(self.worker_download, current_url, site_dir, session))
                        
                    concurrent.futures.wait(futures)

            self.log(f"\n[+] Clone complete! Saved to: {site_dir}")

        except Exception as e:
            self.log(f"[!] Error: {e}")

def main():
    os.system("title Website Cloner Tool")
    os.system("color 0A")
    
    while True:
        os.system("cls")
        
        print(ASCII_LOGO)
        print("="*100)
        print("   Website Cloner - by AlphA")
        print("="*100)
        print("Enter website to clone")
        
        raw_url = input("\n> URL: ").strip()
        
        if not raw_url:
            print("[!] No URL entered. Press Enter to restart.")
            input()
            continue

        if not raw_url.startswith("http://") and not raw_url.startswith("https://"):
            url = "https://" + raw_url
        else:
            url = raw_url

        cloner = WebsiteCloner()
        cloner.clone_website(url)
        
        print("\nDownload ended! check downloads for your cloned website.")
        input("\nPress Enter to return to main menu...")

if __name__ == "__main__":
    main()